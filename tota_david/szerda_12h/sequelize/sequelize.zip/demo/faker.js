const { faker } = require('@faker-js/faker');

console.log(faker.internet.email());
